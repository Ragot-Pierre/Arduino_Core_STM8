/*	LARGE STACK MODEL FOR STM8 COMPILER
 *	Copyright (c) 2006 by COSMIC Software
 */
#pragma space () @far
#pragma space * () @far
#pragma space const []

#define __MODSL__	1
